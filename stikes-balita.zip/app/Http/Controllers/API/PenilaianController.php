<?php

namespace App\Http\Controllers\API;

use App\Http\Traits\PenilaianTraits;
use App\Models\Penilaian;



class PenilaianController extends BaseController
{

    use PenilaianTraits;

    public function getPenilaian($tanggal_lahir){

        $usia_bayi = $this->getRentangBulan($tanggal_lahir);

        $penilaian = Penilaian::whereRelation('usia_bayi', 'rentang', '=', $usia_bayi)->select(['text'])->get();

        return $this->success(  
            $penilaian,    
            $this->getRentangBulan($tanggal_lahir));
    }


}
