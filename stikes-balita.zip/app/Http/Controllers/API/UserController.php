<?php


namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;
use App\Http\Requests\RegisterRequest;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class UserController extends Controller
{
    public function login(Request $request)
    {
        if(Auth::attempt(['email' => $request->email, 'password' => $request->password])){ 
            $user = Auth::user(); 
            $success['token'] =  $user->createToken('MyApp')-> accessToken; 
            $success['name'] =  $user->name;
   
            $response = [
                'success' => true,
                'message' => "Login Success",
            ];
    
            return response()->json($response, 400);
        } 
        else{ 
            $response = [
                'success' => false,
                'message' => "Unauthorized",
            ];
    
            return response()->json($response, 400);
        } 
    }

    public function register(RegisterRequest $request)
    {
        
        $validated = $request->validated();

        if($validated){

            $input = $request->all();
            $input['password'] = bcrypt($input['password']);
            $user = User::create($input);
            $success['token'] =  $user->createToken('MyApp')->accessToken;

            $response = [
                'success' => true,
                'message' => "Berhasil Mendaftarkan Akun",
            ];
            return response()->json($response, 200);    
        }
       
      
    }
   
}